<?php
$myfile = fopen("/var/run/nagios/nagios.lock", "r") or 
die("Unable to open file!"); echo 
fread($myfile,filesize("/var/run/nagios/nagios.lock"));
fclose($myfile);
?>
