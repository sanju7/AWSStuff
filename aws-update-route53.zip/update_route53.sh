#!/bin/bash

# This script is written for nagiosxi for high available in aws environment
# Author: Sanjay Anand <hi@sanjayanand.pro>
# Version: 0.5
# Date: 12-02-2016
# Usages: bash update-route53.sh
# Adjust all the require variables in this file, majorly the AWS keys and route53 details.

# How to setup:
# What things to change on master nagiosxi server ?
# mystatus.php
# What things to change on master nagiosxi server ?
# awscli and mystatus.php

# This is needed to run on nagiosxi secondary server only
# Setup this in cron to after each 2 min
# */2 * * * * bash update-route53.sh

# (optional) You might need to set your PATH variable at the top here
# depending on how you run this script
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin

# Test if awscli is installed
test -f /usr/local/bin/aws || echo "Error: awscli not installed" ; exit 0

# AWS details
AWS_ACCESS_KEY="xxxxxxxxxxxxxxxxxxx"
AWS_SECRET_KEY="xxxxxxxxxxxxxxxxxxxxxxxxxxx"
AWS_REGION="us-west-2"

# Route53 details
# Hosted Zone ID e.g. BJBK35SKMM9OE
ZONEID="Z1FTTDLJLYDXSD"
# The CNAME you want to update e.g. hello.example.com
RECORDSET="watchdog.cisco.io"
# More advanced options below
# The Time-To-Live of this recordset
TTL=30
# Change this if you want
COMMENT="Auto updating @ `date`"
# Change to AAAA if using an IPv6 address
TYPE="A"

# Nagios instance id's
MASTER_INSTANCE_ID='i-06fddcf91e49e8410'
BACKUP_INSTANCE_ID='i-0da703b10900fa98a'

# Get current dir
# (from http://stackoverflow.com/a/246128/920350)
#DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DIR="/tmp"
LOGFILE="$DIR/update-route53.log"
IPFILE="$DIR/update-route53.ip"
re='^[0-9]+$'

MASTERIP=$(AWS_DEFAULT_REGION=$AWS_REGION AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY" AWS_SECRET_ACCESS_KEY="$AWS_SECRET_KEY" aws ec2 describe-instances --instance-ids $MASTER_INSTANCE_ID | grep PrivateIpAddress | tail -1 | awk '{print $NF}'|xargs)
BACKUPIP=$(AWS_DEFAULT_REGION=$AWS_REGION AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY" AWS_SECRET_ACCESS_KEY="$AWS_SECRET_KEY" aws ec2 describe-instances --instance-ids $BACKUP_INSTANCE_ID | grep PrivateIpAddress | tail -1 | awk '{print $NF}' |xargs)
#IP=`wget -qO- http://instance-data/latest/meta-data/local-ipv4`
NAGXI_URL="http://$MASTERIP/mystatus.php"

# Do health check before acting..
_health() {
         MASTER_STATE="$(curl -sL -w "%{http_code}\\n" "$NAGXI_URL" -o /dev/null)"
         # Require mystatus.php on master /var/www/html/
         MASTER_NAG="$(curl --max-time 20 --silent "$NAGXI_URL" 2>&1)"
         if [ "$MASTER_STATE" != "200" ] ;then
            echo "Master nagios is failed"
            export MASTER_FAILED='true'
         elif ! [[ "$MASTER_NAG" =~ $re ]] ;then
            echo "Master nagios is failed"
            export MASTER_FAILED='true'
         else
            echo "Master is up and running"
            export MASTER_FAILED='false'
         fi
         CURRENTIP=$(AWS_DEFAULT_REGION=$AWS_REGION AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY" AWS_SECRET_ACCESS_KEY="$AWS_SECRET_KEY" aws route53 list-resource-record-sets --hosted-zone-id $ZONEID --query "ResourceRecordSets[?Name == '$RECORDSET.']" | grep 'Value' | awk '{print $NF}'|xargs)
         if [ "$BACKUPIP" = "$CURRENTIP" ] ; then
             echo "Backup server $BACKUPIP is already promoted to master domain..."
             export PROMOTED_MASTER='true'
         else
             export PROMOTED_MASTER='false'
         fi
}

_valid_ip()
{
    local  ip=$1
    local  stat=1

    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
            && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    return $stat
}

_start_flip(){
    local  IP=$1
    if ! _valid_ip $IP; then
        echo "Invalid IP address: $IP" >> "$LOGFILE"
        exit 1
    fi

    echo "IP has changed to $IP" >> "$LOGFILE"
    # Fill a temp file with valid JSON
    TMPFILE=$(mktemp /tmp/temporary-file.XXXXXXXX)
    cat > ${TMPFILE} << EOF
    {
      "Comment":"$COMMENT",
      "Changes":[
        {
          "Action":"UPSERT",
          "ResourceRecordSet":{
            "ResourceRecords":[
              {
                "Value":"$IP"
              }
            ],
            "Name":"$RECORDSET",
            "Type":"$TYPE",
            "TTL":$TTL
          }
        }
      ]
    }
EOF

    # Update the Hosted Zone record
    AWS_DEFAULT_REGION=$AWS_REGION AWS_ACCESS_KEY_ID="$AWS_ACCESS_KEY" AWS_SECRET_ACCESS_KEY="$AWS_SECRET_KEY" aws route53 change-resource-record-sets \
        --hosted-zone-id $ZONEID \
        --change-batch file://"$TMPFILE" >> "$LOGFILE"
    echo "" >> "$LOGFILE"

    # Clean up
    rm $TMPFILE
}

_main() {
        _health
        if [ "$MASTER_FAILED" = 'true' ] && [ "$PROMOTED_MASTER" = 'false' ] ;then
             echo "Failover from master to backup nagiosxi $BACKUPIP ..."
            service nagios start ; service httpd start
            _start_flip "$BACKUPIP"
            sleep 10
        elif [ "$MASTER_FAILED" = 'false' ] && [ "$PROMOTED_MASTER" = 'true' ] ;then
             echo "Failing back from backup to master nagiosxi $MASTERIP ..."
            _start_flip "$MASTERIP"
            sleep 10
            service nagios stop ; service httpd stop
        else
            echo "Working all good"
            exit 0
        fi
}

_main
# Exit